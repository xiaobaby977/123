#!/system/bin/sh
# shellcheck disable=SC1091
# shellcheck disable=SC2154
MODDIR=${0%/*}
slot="$(getprop ro.boot.slot_suffix)"
if [ -f "$MODDIR"/vendor_boot"$slot".img ]; then
  dd if="$MODDIR"/vendor_boot"$slot".img of=/dev/block/by-name/vendor_boot"$slot" >/dev/null 2>&1
fi
