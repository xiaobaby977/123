#!/system/bin/sh
# shellcheck disable=SC1091
# shellcheck disable=SC2154
MODDIR=${0%/*}
. "$MODDIR"/functions/FEAS
slot="$(getprop ro.boot.slot_suffix)"
if [ -f "$MODDIR"/vendor_boot"$slot".img ]; then
  dd if="$MODDIR"/vendor_boot"$slot".img of=/dev/block/by-name/vendor_boot"$slot" >/dev/null 2>&1
fi
if [ "$FEASEnabler" = "installed" ]; then
  rm -rf /dev/mount_lib/libmigui.so
fi
if [ "$FEAS_Effect" = "FEASJoyose" ]; then
  killall -9 com.xiaomi.joyose
  am force-stop com.xiaomi.joyose
  am kill com.xiaomi.joyose
  pm clear com.xiaomi.joyose
  pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
  am startservice com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
fi
rm -rf "$MODDIR"
