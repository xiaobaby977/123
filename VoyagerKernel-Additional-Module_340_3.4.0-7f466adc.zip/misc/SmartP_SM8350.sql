/*
 Navicat Premium Data Transfer

 Source Server         : SmartP_SM8350
 Source Server Type    : SQLite
 Source Server Version : 3035005
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3035005
 File Encoding         : 65001

 Date: 13/07/2024 15:47:03
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for cloud_config
-- ----------------------------
DROP TABLE IF EXISTS "cloud_config";

CREATE TABLE "cloud_config" (
  "_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "config_name" TEXT,
  "group_name" TEXT,
  "enable" INTEGER,
  "version" INTEGER,
  "with_model" INTEGER,
  "model" TEXT,
  "params" TEXT,
  "anchor" TEXT,
  "anchor_percents" TEXT,
  "anchor_values" TEXT,
  "value_type" TEXT,
  "final_value" TEXT,
  UNIQUE ("config_name" ASC)
);

-- ----------------------------
-- Records of cloud_config
-- ----------------------------
INSERT INTO "cloud_config" VALUES (1, 'common_config', 'common_config', 1, 2024123199, 0, 'null', '{
  "debug_log_collect_config": {
    "L1_threshold_gap": 10,
    "L1_threshold_jank_percent": 5,
    "L2_threshold_gap": 20,
    "L2_threshold_jank_percent": 10,
    "L3_threshold_curFPS": 20,
    "debug_log_switch": true,
    "log_keep_days": 1,
    "top_process_num": 5
  },
  "game_list": [
    "cn.jj",
    "com.activision.callofduty.shooter",
    "com.aligames.kuang.kybc.mi",
    "com.aniplex.fategrandorder",
    "com.assassingames.ninjafrogrope.mt",
    "com.bf.sgs.hdexp.mi",
    "com.bf.sgs.hdexp",
    "com.bilibili.azurlane",
    "com.bilibili.blhx.mi",
    "com.bilibili.fgo.mi",
    "com.bilibili.fnmzl.mi",
    "com.blizzard.diablo.immortal",
    "com.carrot.carrotfantasy",
    "com.carrot.iceworld",
    "com.chuxi.kjxd2.toutiao4",
    "com.cygames.Shadowverse",
    "com.dfjz.moba",
    "com.duoku.sjsdzx.mi",
    "com.dw.h5yvzr.yt",
    "com.ea.games.nfs13_row",
    "com.easygame2022.sheepmatchcn.mi",
    "com.easygame2022.sheepmatchcn",
    "com.feiyu.carrot3.mi",
    "com.feiyu.luobo4.mi",
    "com.feiyu.luobo4",
    "com.gzzr.sdkb.mi",
    "com.happyelements.AndroidAnimal.ad",
    "com.happyelements.AndroidAnimal.qq",
    "com.happyelements.AndroidAnimal",
    "com.hermes.ygame.mi",
    "com.hottagames.hotta.mi",
    "com.hypergryph.arknights",
    "com.keepmobi.wanningxiangqidazhaoban",
    "com.kiloo.subwaysurf",
    "com.kunpo.kok.mi",
    "com.kurogame.haru.hero",
    "com.kurogame.haru.mi",
    "com.lilithgames.rok.offical.cn",
    "com.mfp.jelly.official",
    "com.mfp.jelly.xiaomi",
    "com.miHoYo.bh3.bilibili",
    "com.miHoYo.bh3.mi",
    "com.miHoYo.bh3korea",
    "com.miHoYo.bh3tw",
    "com.miHoYo.cloudgames.ys",
    "com.miHoYo.enterprise.NGHSoD",
    "com.miHoYo.enterprise.NGHSoDBeta",
    "com.miHoYo.GenshinImpact",
    "com.miHoYo.hkrpg",
    "com.miHoYo.ys.bilibili",
    "com.miHoYo.ys.mi",
    "com.miHoYo.Yuanshen",
    "com.netease.dfjs.mi",
    "com.netease.dwrg.bili",
    "com.netease.dwrg.mi",
    "com.netease.dwrg",
    "com.netease.g67.bilibili",
    "com.netease.g67.mi",
    "com.netease.g67",
    "com.netease.h48.mi",
    "com.netease.h48",
    "com.netease.harrypotter.bilibili",
    "com.netease.harrypotter.mi",
    "com.netease.harrypotter",
    "com.netease.hyxd.mi",
    "com.netease.hyxd",
    "com.netease.jddsaef.mi",
    "com.netease.jddsaef",
    "com.netease.lglr",
    "com.netease.lx12.mi",
    "com.netease.lztg.baidu",
    "com.netease.lztg",
    "com.netease.lztg1.mi",
    "com.netease.mc.mi",
    "com.netease.mhxyhtb",
    "com.netease.moba.ewan",
    "com.netease.moba.mi",
    "com.netease.my.mi",
    "com.netease.my",
    "com.netease.myd",
    "com.netease.nshm.mi",
    "com.netease.nshm",
    "com.netease.onmyoji.mi",
    "com.netease.onmyoji",
    "com.netease.party.mi",
    "com.netease.party",
    "com.netease.pes.mi",
    "com.netease.pes",
    "com.netease.race",
    "com.netease.tom.m4399",
    "com.netease.tom.mi",
    "com.netease.tom",
    "com.netease.x19",
    "com.nextwave.wcc2",
    "com.pandadastudio.ninjamustdie3.mi",
    "com.pandadastudio.ninjamustdie3",
    "com.pdragon.weiqi.mi",
    "com.protopop.brightridge.shiba",
    "com.protopop.brightridge",
    "com.pwrd.hotta.laohu",
    "com.pwrd.tzyxmznew.mi",
    "com.pwrd.tzyxmznew",
    "com.pwrd.zsyj.laohu",
    "com.pwrd.zsyj.mi",
    "com.qmzg2.mi",
    "com.qqgame.hlddz",
    "com.riotgames.league.wildrift",
    "com.seasun.jxp.mi",
    "com.seasun.jxp",
    "com.slsmfx.union.mi",
    "com.songwo.zgyx.mi",
    "com.square_enix.android_googleplay.nierspjp",
    "com.square_enix.android_googleplay.nierspww",
    "com.standddz003.mi",
    "com.sy.dldlhsdj.mi",
    "com.t2ksports.nba2k20and",
    "com.tencent.af",
    "com.tencent.fifamobile",
    "com.tencent.ig",
    "com.tencent.jkchess",
    "com.tencent.lolm",
    "com.tencent.nbn",
    "com.tencent.ngjp",
    "com.tencent.tmgp.bh3",
    "com.tencent.tmgp.cf",
    "com.tencent.tmgp.cod",
    "com.tencent.tmgp.codev",
    "com.tencent.tmgp.dwrg",
    "com.tencent.tmgp.gnyx",
    "com.tencent.tmgp.gnyxce",
    "com.tencent.tmgp.pandadastudio.ninja3",
    "com.tencent.tmgp.pubgmhd",
    "com.tencent.tmgp.sgame",
    "com.tencent.tmgp.sgamece",
    "com.tencent.tmgp.letsgo",
    "com.tencent.tmgp.speedmobile",
    "com.tencent.tmgp.speedmobileEx",
    "com.tencent.tmgp.supercell.brawlstars",
    "com.tencent.tmgp.WePop",
    "com.tencent.toaa",
    "com.vgamecrty.projv",
    "com.vng.g6.a.zombie",
    "com.wanmei.zhuxian.mi",
    "com.wanmei.zhuxian",
    "com.wingjoy.massive",
    "com.xmyp.hdsc.mi",
    "com.yinhan.hunter.mi",
    "com.yinhan.hunter",
    "com.YoStarEN.Arknights",
    "com.youzu.snsgz2.mi",
    "com.zf.wkxns.mi",
    "com.zlongame.coside.mi",
    "com.zlongame.mhmnz.mi",
    "com.zlongame.mhmnz",
    "cricketgames.hitwicket.strategy",
    "weile.baohuang.mi"
  ],
  "support_app": [
    "cn.jj.log.mi",
    "cn.jj",
    "com.activision.callofduty.shooter",
    "com.aligames.kuang.kybc.mi",
    "com.aniplex.fategrandorder",
    "com.apollo.arrival",
    "com.asia.arrival",
    "com.assassingames.ninjafrogrope.mt",
    "com.baitian.aobi.czs.mi",
    "com.baitian.aobi",
    "com.bandainamcoent.dblegends_ww",
    "com.bf.sgs.hdexp.mi",
    "com.bf.sgs.hdexp",
    "com.bilibili.azurlane",
    "com.bilibili.blhx.mi",
    "com.bilibili.deadcells.mobile.mi",
    "com.bilibili.fgo.mi",
    "com.bilibili.fnmzl.mi",
    "com.bilibili.priconne.mi",
    "com.bilibili.priconne",
    "com.bilibili.snake.mi",
    "com.bilibili.snake",
    "com.brianbaek.popstar",
    "com.bytedance.ttgame.gameturbodemo",
    "com.carrot.carrotfantasy",
    "com.carrot.iceworld",
    "com.ChillyRoom.DungeonShooter",
    "com.chuxi.kjxd2.toutiao4",
    "com.cis.jiangnan.coconut",
    "com.cis.jiangnan.mi",
    "com.cis.jiangnan.taptap",
    "com.crisisfire.android.mi",
    "com.crisisfire.cmge",
    "com.cygames.Shadowverse",
    "com.denachina.g13002010.denacn",
    "com.denachina.g13002010.mi",
    "com.dfjz.moba",
    "com.dts.freefiremax",
    "com.dts.freefireth",
    "com.duoku.sisdzx.mi",
    "com.duoku.sjsdzx.mi",
    "com.duole.doudizhuhd.mi",
    "com.dw.h5yvzr.yt",
    "com.ea.games.nfs13_row",
    "com.ea.games.r3_na",
    "com.ea.games.r3_row",
    "com.easygame2022.sheepmatchcn.mi",
    "com.easygame2022.sheepmatchcn",
    "com.ehearts.shendu.mi",
    "com.feiyu.carrot3.mi",
    "com.feiyu.luobo4.mi",
    "com.feiyu.luobo4",
    "com.fingersoft.hillclimb",
    "com.fy.wdxd.mi",
    "com.gameloft.android.ANMP.GloftA9HM",
    "com.garena.game.codm",
    "com.garena.game.kgcn",
    "com.garena.game.kgid",
    "com.garena.game.kgsam",
    "com.garena.game.kgth",
    "com.garena.game.kgtw",
    "com.garena.game.kgvn",
    "com.garena.game.kgvntest",
    "com.garena.game.vntest",
    "com.gravity.romg",
    "com.gravity.romNAg",
    "com.guandan.mi",
    "com.gzzr.sdkb.mi",
    "com.happyelements.AndroidAnimal.ad",
    "com.happyelements.AndroidAnimal.qq",
    "com.happyelements.AndroidAnimal",
    "com.happyelements.TsumTsumAndroid.mi",
    "com.hermes.douyin.j1game",
    "com.hermes.h1game.mi",
    "com.hermes.h1game",
    "com.hermes.j1game",
    "com.hermes.ygame.mi",
    "com.hl.cjss.mi",
    "com.hottagames.hotta.mi",
    "com.hypergryph.arknights",
    "com.idreamsky.sar",
    "com.ilongyuan.zzq.mi",
    "com.japan.arrival",
    "com.jn.performancesdk.demo",
    "com.joydo.cnr.mi",
    "com.joydo.cnr",
    "com.keepmobi.wanningxiangqidazhaoban",
    "com.kiloo.subwaysurf",
    "com.king.candycrushsaga.bnn",
    "com.knight.union.mi",
    "com.korea.arrival",
    "com.kunpo.kok.mi",
    "com.kunpo.kok.mig",
    "com.kurogame.haru.hero",
    "com.kurogame.haru.mi",
    "com.lanjing.yanyu.mi",
    "com.leiting.aobi",
    "com.leiting.yunshiwinter.mi",
    "com.lilithgames.rok.offical.cn",
    "com.longtugame.yjfb.mi",
    "com.mewe.wolf",
    "com.mfp.jelly.official",
    "com.mfp.jelly.xiaomi",
    "com.miHoYo.bh3.bilibili",
    "com.miHoYo.bh3.mi",
    "com.miHoYo.bh3.uc",
    "com.miHoYo.bh3global",
    "com.miHoYo.bh3korea",
    "com.miHoYo.bh3oversea",
    "com.miHoYo.bh3tw",
    "com.miHoYo.cloudgames.ys",
    "com.miHoYo.enterprise.NGHSoD",
    "com.miHoYo.enterprise.NGHSoDBeta",
    "com.miHoYo.GenshinImpact",
    "com.miHoYo.hkrpg",
    "com.miHoYo.ys.bilibili",
    "com.miHoYo.ys.mi",
    "com.miHoYo.Yuanshen",
    "com.mobile.legends:UnityKillsMe",
    "com.mobile.legends",
    "com.mobilelegends.amazon",
    "com.mobilelegends.bp",
    "com.mobilelegends.shareit",
    "com.movile.playkids.pkxd",
    "com.nd.he.mi",
    "com.netease.aceracer.mi",
    "com.netease.aceracer",
    "com.netease.dfjs.mi",
    "com.netease.dwrg.bili",
    "com.netease.dwrg.mi",
    "com.netease.dwrg",
    "com.netease.g104.cn",
    "com.netease.g104.mi",
    "com.netease.g67.mi",
    "com.netease.g67",
    "com.netease.h48.mi",
    "com.netease.h48",
    "com.netease.harrypotter.bilibili",
    "com.netease.harrypotter.mi",
    "com.netease.harrypotter",
    "com.netease.hyxd.mi",
    "com.netease.hyxd",
    "com.netease.jddsaef.mi",
    "com.netease.jddsaef",
    "com.netease.lglr",
    "com.netease.lrs.mi",
    "com.netease.lrs",
    "com.netease.lx12.mi",
    "com.netease.mc.mi",
    "com.netease.mhxyhtb",
    "com.netease.moba.ewan",
    "com.netease.moba.mi",
    "com.netease.moba",
    "com.netease.mrzh.mi",
    "com.netease.mrzh",
    "com.netease.my.mi",
    "com.netease.my",
    "com.netease.myd",
    "com.netease.nshm.mi",
    "com.netease.nshm",
    "com.netease.onmyoji.mi",
    "com.netease.onmyoji",
    "com.netease.party.mi",
    "com.netease.party",
    "com.netease.pes.mi",
    "com.netease.pes",
    "com.netease.pm02",
    "com.netease.race",
    "com.netease.sky.mi",
    "com.netease.sky",
    "com.netease.tom.m4399",
    "com.netease.tom.mi",
    "com.netease.tom",
    "com.netease.wotb.mi",
    "com.netease.wotb",
    "com.netease.wyclx.mi",
    "com.netease.wyclx",
    "com.netease.x19",
    "com.netease.yokaikoya.mi",
    "com.netease.yokaikoya",
    "com.netease.yysbwp.mi",
    "com.netease.yysbwp",
    "com.netmarble.penta",
    "com.newbility.monsterbook.aligames",
    "com.nextwave.wcc2",
    "com.ngame.allstar.eu",
    "com.ngame.allstar.in",
    "com.pandadastudio.ninjamustdie3.mi",
    "com.pandadastudio.ninjamustdie3",
    "com.papegames.nn4.mi",
    "com.pdragon.weiqi.mi",
    "com.plarium.mechlegion",
    "com.popcap.pvz2cthdxm",
    "com.protopop.brightridge.shiba",
    "com.protopop.brightridge",
    "com.pubg.imobile",
    "com.pubg.krmobile",
    "com.pwrd.hotta.laohu",
    "com.pwrd.tzyxmznew.mi",
    "com.pwrd.tzyxmznew",
    "com.pwrd.zsyj.laohu",
    "com.pwrd.zsyj.mi",
    "com.qmzg2.mi",
    "com.qqgame.hlddz",
    "com.rekoo.pubgm",
    "com.riotgames.internal.wildrift.test",
    "com.riotgames.internal.wildrift.trunk",
    "com.riotgames.league.teamfighttactics",
    "com.riotgames.league.wildrift",
    "com.riotgames.league.wildrifttw",
    "com.riotgames.league.wildriftvn",
    "com.seasun.jxp.jsml.xsj",
    "com.seasun.jxp.mi",
    "com.seasun.jxp",
    "com.sixjoy.warsong1",
    "com.slsmfx.union.mi",
    "com.songwo.zgyx.mi",
    "com.soulpainter.qise.mi",
    "com.square_enix.android_googleplay.nierspjp",
    "com.square_enix.android_googleplay.nierspww",
    "com.standddz003.mi",
    "com.studiowildcard.wardrumstudios.ark.ncr",
    "com.supercell.clashofclans.mi",
    "com.sy.dldlhsdj.azt",
    "com.sy.dldlhsdj.mi",
    "com.sy.dldlhsdj.vivo",
    "com.sy.ysczg.taptap",
    "com.t2ksports.nba2k20and",
    "com.tanwan.yscq.mi",
    "com.taomee.molenew.mi",
    "com.taomee.molenew",
    "com.tencent.af",
    "com.tencent.fifamobile",
    "com.tencent.forest",
    "com.tencent.gwgo",
    "com.tencent.hxh",
    "com.tencent.hyrzol",
    "com.tencent.ig",
    "com.tencent.igce",
    "com.tencent.jkchess",
    "com.tencent.kgvmptest",
    "com.tencent.KiHan",
    "com.tencent.kof",
    "com.tencent.lgame",
    "com.tencent.lolm",
    "com.tencent.lzhx",
    "com.tencent.mf.uam",
    "com.tencent.mxdl",
    "com.tencent.nbn",
    "com.tencent.ngjp",
    "com.tencent.peng",
    "com.tencent.qs",
    "com.tencent.raziel",
    "com.tencent.sgwsba",
    "com.tencent.shihun.android",
    "com.tencent.shootgame",
    "com.tencent.tmgp.bh3",
    "com.tencent.tmgp.cf",
    "com.tencent.tmgp.cfalpha",
    "com.tencent.tmgp.cod",
    "com.tencent.tmgp.codev",
    "com.tencent.tmgp.djsy",
    "com.tencent.tmgp.dnf",
    "com.tencent.tmgp.dpcq",
    "com.tencent.tmgp.dwrg",
    "com.tencent.tmgp.gnyx",
    "com.tencent.tmgp.gnyxce",
    "com.tencent.tmgp.jx3m",
    "com.tencent.tmgp.jxqy",
    "com.tencent.tmgp.jxqy2",
    "com.tencent.tmgp.mt4",
    "com.tencent.tmgp.NBA",
    "com.tencent.tmgp.nssGame",
    "com.tencent.tmgp.pandadastudio.ninja3",
    "com.tencent.tmgp.pubgm",
    "com.tencent.tmgp.pubgmhd",
    "com.tencent.tmgp.pubgmhdce",
    "com.tencent.tmgp.qqx5",
    "com.tencent.tmgp.redfox",
    "com.tencent.tmgp.sgame",
    "com.tencent.tmgp.sgamece",
    "com.tencent.tmgp.letsgo",
    "com.tencent.tmgp.speedmobile",
    "com.tencent.tmgp.speedmobileEx",
    "com.tencent.tmgp.sskgame",
    "com.tencent.tmgp.supercell.brawlstars",
    "com.tencent.tmgp.supercell.clashofclans",
    "com.tencent.tmgp.tmsk.qj2",
    "com.tencent.tmgp.tstl",
    "com.tencent.tmgp.vgame",
    "com.tencent.tmgp.WePop",
    "com.tencent.tmgp.wuxia",
    "com.tencent.tmgp.ylm",
    "com.tencent.toaa",
    "com.tencent.wdqy",
    "com.tencent.woool3d",
    "com.tencent.xishanju.xj4",
    "com.tencent.YiRen",
    "com.tencent.yoozoo.got.wintercoming",
    "com.threedy.game.blue",
    "com.tuyoo.fish3d.mi",
    "com.tzyz.pao",
    "com.ua.building.Lokicraft",
    "com.vgamecrty.projv",
    "com.vng.g6.a.zombie",
    "com.vng.mlbbvn",
    "com.vng.pubgmobile",
    "com.wanmei.zhuxian.laohu",
    "com.wanmei.zhuxian.mi",
    "com.wanmei.zhuxian",
    "com.wb.elsfkx.mi",
    "com.wepie.snake.new.mi",
    "com.wingjoy.massive",
    "com.xd.fkzxc.new.mi",
    "com.xd.mnccc.mi",
    "com.xinline.td.mi",
    "com.xmyp.hdsc.mi",
    "com.xy.lzzx.g.baidu",
    "com.xy.lzzx.guanfang",
    "com.xy.lzzx.mi",
    "com.yingxiong.dftk1.mi",
    "com.yingxiong.hero.mi",
    "com.yinhan.hunter.mi",
    "com.yinhan.hunter",
    "com.yodo1.SkiSafari.XIAOMI_01",
    "com.yoka.sgstenth.mi",
    "com.YoStarEN.Arknights",
    "com.youzu.bs.mi",
    "com.youzu.bs",
    "com.yyzy.mi",
    "com.zlongame.coside.mi",
    "com.zlongame.lzgwy.mi",
    "com.zlongame.lzgwy.pd",
    "com.zlongame.mhmnz.mi",
    "com.zlongame.mhmnz",
    "com.zlongame.sea.cside",
    "com.zlongame.tdj.mi",
    "cricketgames.hitwicket.strategy",
    "jp.konami.pesam",
    "net.froemling.bombsquad",
    "net.hexage.reaper.mi",
    "org.cocos2d.hellomerge",
    "weile.baohuang.mi"
  ]
}', NULL, NULL, NULL, NULL, NULL);

INSERT INTO "cloud_config" VALUES (2, 'booster_config', 'booster_config', 1, 2024123199, 0, 'null', '{
    "game_booster": {
      "background_freeze_enable": true,
      "background_freeze_whitelist": [
        "com.xiaomi.joyose",
        "com.miui.powerkeeper",
        "com.xiaomi.migameservice",
        "mcd",
        "com.xiaomi.gamecenter.sdk.service"
      ],
      "booster_config": {
        "scene_config": [
          {
            "scene_id": 5,
            "scene_name": "loading",
            "booster": [
              {
                "permission": "root",
                "cmd": "perflock#40800000_FFF#20"
              }
            ]
          },
          {
            "scene_id": 1004,
            "end": [
              {
                "permission": "root",
                "cmd": "sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#10;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/nor_f_keep#8;sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/module/perfmgr/parameters/r_perf#0;sys/module/perfmgr/parameters/r_step#280;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/module/perfmgr/parameters/p_freq_level#0"
              }
            ],
            "scene_name": "target_fps_update",
            "booster": [
              {
                "permission": "root",
                "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#7;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/module/perfmgr/parameters/nor_f_keep#11;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
              },
              {
                "permission": "root",
                "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
              }
            ]
          }
        ],
        "default_config": [
          {
            "permission": "root",
            "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
          }
        ],
        "ovrride_config": [
          {
            "game_name": "SGAME",
            "scene_ovrride": [
              {
                "booster#120": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#7;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0;sys/module/perfmgr/parameters/normal_frame_keep_count#12;sys/module/perfmgr/parameters/continus_no_jank_count#12;sys/module/perfmgr/parameters/scaling_a#210;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/scaling_a_thres#500;sys/module/perfmgr/parameters/rescue_performance#1;sys/module/perfmgr/parameters/rescue_step#780;sys/module/perfmgr/parameters/predict_freq_level#1;sys/module/perfmgr/parameters/max_freq_limit_level#28"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_0_40CE0100_005F0042_40CE0200_00640060_40C3C000_F8_40C40000_7F_5FC00000_7F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#UnityGfx:1:3:6,UnityMain:1:7:7,CoreThread:1:3:6,Thread-:10:3:6;/data/system/mcd/raf_debug#2"
                  }
                ],
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/predict_freq_level#0;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/rescue_performance#0;sys/module/perfmgr/parameters/rescue_step#280;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/max_freq_limit_level#33"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7;/data/system/mcd/raf_debug#0;/data/system/mcd/policy#0;"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#-3;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#-5;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#2;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#UnityGfx:1:3:6,UnityMain:1:3:7,CoreThread:1:3:6;/data/system/mcd/raf_debug#2"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "group_fight_thresh": 4,
            "end_scene": "4",
            "badfps_thresh1": "54,81,108",
            "badfps_thresh2": "3,5,10"
          },
          {
            "game_name": "PUBG",
            "scene_ovrride": [
              {
                "scene_id": 3,
                "scene_name": "login",
                "change_end": true,
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 5,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/predict_freq_level#0;sys/module/perfmgr/parameters/rescue_performance#0;sys/module/perfmgr/parameters/rescue_step#280;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/max_freq_limit_level#33;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/predict_freq_level#0;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1;/data/system/mcd/raf_debug#0;/data/system/mcd/policy#0"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/rescue_performance#1;sys/module/perfmgr/parameters/rescue_step#780;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#12;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0;sys/module/perfmgr/parameters/normal_frame_keep_count#12;sys/module/perfmgr/parameters/continus_no_jank_count#10;sys/module/perfmgr/parameters/scaling_a#300;sys/module/perfmgr/parameters/scaling_b#-30;sys/module/perfmgr/parameters/scaling_a_thres#530;sys/module/perfmgr/parameters/predict_freq_level#1;sys/module/perfmgr/parameters/max_freq_limit_level#28"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/migt/parameters/boost_policy#0;/data/system/mcd/policy#RenderThread:1:3:6;/data/system/mcd/raf_debug#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_0_40CE0000_00500046_40CE0200_005A0050_5FC00000_7F#0"
                  }
                ]
              }
            ],
            "start_scene": "102",
            "end_scene": "3",
            "badfps_thresh1": "54,81",
            "badfps_thresh2": "3,5"
          },
          {
            "game_name": "CODM",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/predict_freq_level#0;sys/module/perfmgr/parameters/load_scaling_y#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1;dev/cpuset/foreground/cpus#0-7;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0;sys/module/perfmgr/parameters/scaling_a_thres#800;sys/module/perfmgr/parameters/predict_freq_level#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "end_scene": "4"
          },
          {
            "game_name": "com.tencent.lolm",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#2;sys/module/perfmgr/parameters/predict_freq_level#0;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/rescue_performance#0;sys/module/perfmgr/parameters/rescue_step#750;sys/module/perfmgr/parameters/continus_no_jank_count#0;"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#3-7;sys/devices/system/cpu/cpu7/core_ctl/enable#1"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0;sys/module/perfmgr/parameters/normal_frame_keep_count#12;sys/module/perfmgr/parameters/scaling_a#400;sys/module/perfmgr/parameters/scaling_b#-75;sys/module/perfmgr/parameters/scaling_a_thres#500;sys/module/perfmgr/parameters/predict_freq_level#1;sys/module/perfmgr/parameters/rescue_performance#1;sys/module/perfmgr/parameters/rescue_step#780;sys/module/perfmgr/parameters/continus_no_jank_count#10"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/module/migt/parameters/boost_policy#0;/data/system/mcd/policy#Thread-1:10:3:6,Thread-5:10:3:6,Thread-2:10:3:6,Thread-3:10:3:6,Thread-4:10:3:6,UnityMain:1:7:7;/data/system/mcd/raf_debug#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_0_40CE0000_005F0055_40CE0200_0064005F_40C40000_F8_40C3C000_F8_5FC00000_7F#0"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "group_fight_thresh": 4,
            "end_scene": "4",
            "badfps_thresh1": "54,81,108",
            "badfps_thresh2": "3,5,10"
          },
          {
            "game_name": "com.netease.lglr",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#-3 994125:-7 1435500:-11 1881000:-15 2338875:-19;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/scaling_a#350;sys/module/perfmgr/parameters/scaling_b#-70;sys/module/perfmgr/parameters/normal_frame_keep_count#10;sys/module/perfmgr/parameters/predict_freq_level#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "android.process.acore",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#-3 994125:-7 1435500:-11 1881000:-15 2338875:-19;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/scaling_a#350;sys/module/perfmgr/parameters/scaling_b#-70;sys/module/perfmgr/parameters/normal_frame_keep_count#10;sys/module/perfmgr/parameters/predict_freq_level#1sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/scaling_a#250;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#10;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7;sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7"
                  }
                ]
              }
            ]
          },
          {
            "PID_M": "60#10:0 61 61 0 0 0,42:42 45 45 0 0 0,43:43 30 30 0 0 0",
            "PID_RE2_T": "60#10:0 61 61 0 0 0,47:47 30 30 10 0.8 3",
            "game_name": "YUANSHEN",
            "PID_RE3_T": "60#10:0 45 45 0 0 0,47:47 30 30 10 0.8 3",
            "PID_RE4_T": "60#10:0 30 30 0 0 0,47:47 25 25 10 0.8 3",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;/data/system/mcd/raf_debug#0;/data/system/mcd/policy#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/rescue_performance#0;sys/module/perfmgr/parameters/rescue_step#750;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy0/schedutil/target_loads#0 902400:-5 1017600:-30;/sys/devices/system/cpu/cpufreq/policy3/schedutil/target_loads#0 1286400:-15 1785600:-5 1920000:-30;/sys/devices/system/cpu/cpufreq/policy7/schedutil/target_loads#0 1248000:-10 1593600:-15 1843200:-30;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#600000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#8;sys/module/perfmgr/parameters/max_freq_limit_level#28;sys/module/perfmgr/parameters/continus_no_jank_count#13;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-20;sys/module/perfmgr/parameters/normal_frame_keep_count#12;sys/module/perfmgr/parameters/predict_freq_level#1;sys/module/perfmgr/parameters/scaling_a_thres#900;sys/module/perfmgr/parameters/rescue_performance#1;sys/module/perfmgr/parameters/rescue_step#780"
                  },
                  {
                    "permission": "root",
                    "cmd": "perfhint#00001055_1_1#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/migt/parameters/boost_policy#0;/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityMultiRende:1:3:6,Worker Thread:3:3:6"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_00500046_40CE0200_00500046_40C3C000_F8_5FC00000_7F#0"
                  }
                ]
              }
            ],
            "PID_RE5_T": "60#10:0 61 61 0 0 0,42.6:42.5 45 45 0 0 0,45:45 30 30 0 0 0",
            "PID_T": "60#10:0 61 61 0 0 0,47:47 45 45 0 0 0,48:48 30 30 0 0 0",
            "PID_RE2_M": "60#10:0 61 61 0 0 0,43:43 30 30 10 1 2",
            "PID_RE3_M": "60#10:0 45 45 0 0 0,43:43 30 30 10 1 2",
            "PID_RE4_M": "60#10:0 30 30 0 0 0,43:43 25 25 10 1 2",
            "PID_RE5_M": "60#10:0 30 30 0 0 0,43:43 25 25 10 1 2"
          },
          {
            "PID_M": "60#10:0 60 60 0 0 0,41.5:42 45 45 0 0 0,42.5:43 30 30 0 0 0",
            "dcs_config": {
              "booster#60#MGAME": {
                "invalid_temp": "44",
                "disable_scenes": "0",
                "boost_interval": "10",
                "fps_thresh": "3, 2",
                "glk_max_range": "1228800,1536000,1248000-1228800,1651200,1593600"
              },
              "booster#60": {
                "invalid_temp": "46",
                "disable_scenes": "0",
                "boost_interval": "6",
                "fps_thresh": "3, 2",
                "glk_max_range": "1228800,1785600,1248000-1228800,2188800,1843200"
              }
            },
            "game_name": "com.miHoYo.hkrpg",
            "scene_ovrride": [
              {
                "scene_id": 10001,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,595200;MA#2016000,2803200,2956800;WA#0;BI#0;BP#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;/sys/devices/system/cpu/cpufreq/policy0/schedutil/target_loads#0;/sys/devices/system/cpu/cpufreq/policy3/schedutil/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/schedutil/target_loads#0;/sys/devices/system/cpu/cpu3/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#1;/sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#1;/sys/devices/system/cpu/cpufreq/policy0/schedutil/rtg_boost_freq#1000000;/sys/devices/system/cpu/cpufreq/policy0/schedutil/target_load_thresh#1024;/proc/sys/schedutil/sched_asymcap_boost#0;/sys/devices/system/cpu/cpufreq/policy3/schedutil/hispeed_freq#1536000;/sys/devices/system/cpu/cpufreq/policy3/schedutil/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/schedutil/target_load_thresh#1024"
                  },
                  {
                    "permission": "root",
                    "cmd": "rafe#"
                  }
                ],
                "scene_name": "foreground",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#1;BE#0;BP#2;MA#1228800,1785600,1248000;MF#0:0 1:0 2:0 3:499200 4:499200 5:499200 6:499200 7:595200;sys/module/migt/parameters/cpu_boost_cycle#0;/sys/devices/system/cpu/cpufreq/policy0/schedutil/target_loads#0 902400:-15;/sys/devices/system/cpu/cpufreq/policy3/schedutil/target_loads#0 1286400:-10 1920000:-10;/sys/devices/system/cpu/cpufreq/policy7/schedutil/target_loads#0 1132800:-10 1843200:-10;/sys/devices/system/cpu/cpu3/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;/sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;/sys/devices/system/cpu/cpufreq/policy0/schedutil/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy3/schedutil/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/schedutil/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy3/schedutil/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/schedutil/target_load_thresh#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "raf#"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_5FC00000_7F#0"
                  }
                ]
              },
              {
                "scene_id": 10004,
                "scene_name": "coldLaunch",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#10"
                  }
                ]
              }
            ],
            "execute_cmd_by_temp_M": "60@44:glk#MA#1017600,1401600,1286400|40@44:glk#MA#1017600,1401600,1286400|30@44:glk#MA#1056000,1401600,1286400",
            "PID_T": "60#10:0 60 60 0 0 0,45.5:46 60 30 10 0.8 3",
            "dcs_enable": true,
            "execute_cmd_by_temp_T": "60@46:glk#MA#1017600,1920000,1248000|40@46:glk#MA#1017600,1785600,1248000|30@46:glk#MA#1017600,1651200,1248000"
          },
          {
            "game_name": "com.leiting.yunshiwinter.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#-3 994125:-7 1435500:-11 1881000:-15 2338875:-19;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/scaling_a#400;sys/module/perfmgr/parameters/scaling_b#-60;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/predict_freq_level#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "COMMON1",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#-3 994125:-7 1435500:-11 1881000:-15 2338875:-19;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/scaling_a#450;sys/module/perfmgr/parameters/scaling_b#-70;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "COMMON2",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#-3 994125:-7 1435500:-11 1881000:-15 2338875:-19;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/scaling_a#450;sys/module/perfmgr/parameters/scaling_b#-70;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.netease.moba.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#10 1435500:-5 1881000:-10 2338875:-15;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#10 1649625:-5 2128171:-10 2587265:-20;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5;sys/module/perfmgr/parameters/scaling_a#250;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "BH3",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/rescue_performance#0;sys/module/perfmgr/parameters/rescue_step#750;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#5;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#5;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#600000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#9;sys/module/perfmgr/parameters/max_freq_limit_level#28;sys/module/perfmgr/parameters/continus_no_jank_count#25;sys/module/perfmgr/parameters/scaling_a#290;sys/module/perfmgr/parameters/scaling_b#-40;sys/module/perfmgr/parameters/normal_frame_keep_count#12;sys/module/perfmgr/parameters/predict_freq_level#1;sys/module/perfmgr/parameters/scaling_a_thres#900;sys/module/perfmgr/parameters/rescue_performance#1;sys/module/perfmgr/parameters/rescue_step#780"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perfhint#00001055_1_1#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.happyelements.AndroidAnimal",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5;sys/module/perfmgr/parameters/normal_frame_keep_count#10;sys/module/perfmgr/parameters/scaling_a#200;sys/module/perfmgr/parameters/scaling_b#-30"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.cf",
            "scene_ovrride": [
              {
                "scene_id": 5,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/predict_freq_level#0;sys/module/perfmgr/parameters/rescue_performance#0;sys/module/perfmgr/parameters/rescue_step#280;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/max_freq_limit_level#33;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/predict_freq_level#0;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0 2100000:-5 2500000:-10;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0 2100000:-7 2500000:-13;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/rescue_performance#1;sys/module/perfmgr/parameters/rescue_step#780;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#12;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0;sys/module/perfmgr/parameters/normal_frame_keep_count#12;sys/module/perfmgr/parameters/continus_no_jank_count#28;sys/module/perfmgr/parameters/scaling_a#300;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/scaling_a_thres#530;sys/module/perfmgr/parameters/predict_freq_level#1;sys/module/perfmgr/parameters/max_freq_limit_level#28"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "end_scene": "4"
          },
          {
            "game_name": "com.netease.g67.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_x#4;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0;sys/module/perfmgr/parameters/scaling_a_thres#400;sys/module/perfmgr/parameters/predict_freq_level#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.netease.g67",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#2;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0;sys/module/perfmgr/parameters/scaling_a_thres#500;sys/module/perfmgr/parameters/predict_freq_level#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.hypergryph.arknights",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;sys/devices/system/cpu/cpu3/core_ctl/enable#1;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#2;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0;sys/module/perfmgr/parameters/scaling_a_thres#600;sys/module/perfmgr/parameters/predict_freq_level#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.bilibili.hunter3.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#2;sys/module/perfmgr/parameters/perfmgr_enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#-3;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#-5;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#2;sys/module/perfmgr/parameters/min_freq_limit_level#0;sys/module/perfmgr/parameters/boost_minfreq#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "group_fight_thresh": 4,
            "end_scene": "4",
            "badfps_thresh1": "54,81,108",
            "badfps_thresh2": "3,5,10"
          },
          {
            "game_name": "com.tencent.jkchess",
            "scene_ovrride": [
              {
                "scene_id": 1,
                "scene_name": "startgame",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/max_freq_limit_level#35;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_x#4;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/max_freq_limit_level#33;sys/module/perfmgr/parameters/normal_frame_keep_count#12;sys/module/perfmgr/parameters/scaling_a#200;sys/module/perfmgr/parameters/scaling_b#-30"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#4280C000_16C_42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "end_scene": "4"
          },
          {
            "game_name": "com.netease.mc.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_x#3;sys/module/perfmgr/parameters/load_scaling_y#5;sys/module/perfmgr/parameters/normal_frame_keep_count#10;sys/module/perfmgr/parameters/scaling_a#200;sys/module/perfmgr/parameters/scaling_b#-30"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.feiyu.carrot3.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5;sys/module/perfmgr/parameters/normal_frame_keep_count#10;sys/module/perfmgr/parameters/scaling_a#400;sys/module/perfmgr/parameters/scaling_b#-30"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "COMMON3",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.taomee.molenew.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5;sys/module/perfmgr/parameters/load_scaling_x#4"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#4280C000_16C_42C08000_0_43C00000_1_40C20100_14_40C20200_5A_40C1C100_1E_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#0-6;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "DLDL",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0 1401600:10 2457600:5;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0 1478400:-15 2342400:-10;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5;sys/module/perfmgr/parameters/load_scaling_x#4;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/scaling_a#300;sys/module/perfmgr/parameters/scaling_b#-30;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_7F_40C3C000_7F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "COMMON4",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.djsy",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#7;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/scaling_a#400;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_F8_40C3C000_F8_4280C000_1B7#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.leniu.jlsy.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#7;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/scaling_a#400;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.speedmobile",
            "scene_ovrride": [
              {
                "scene_id": 5,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "booster#120": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0 940800:-5 1440000:-10;sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0 1427000:10 2527200:5;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0 1427000:15 2630400:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_x#4;sys/module/perfmgr/parameters/load_scaling_y#-1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/load_scaling_y#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "end_scene": "4"
          },
          {
            "game_name": "HARRYPOTTER",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.hermes.h1game.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#4280C000_16C_42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.KiHan",
            "scene_ovrride": [
              {
                "booster#120": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;dev/cpuset/top-app/cpus#0-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;dev/cpuset/top-app/cpus#3-7;dev/cpuset/foreground/cpus#0-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.fifamobile",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#7;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/scaling_a#300;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "COMMON5",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#4;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/scaling_a#250;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.zz.mm",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#7;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/scaling_a#400;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#0-6"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "COMMON6",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#-1;sys/module/perfmgr/parameters/load_scaling_x#7;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/scaling_a#400;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.taiyouxi.tk2.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#1000000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/load_scaling_x#5;sys/module/perfmgr/parameters/scaling_a_thres#640;sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/module/perfmgr/parameters/target_fps_61#0;sys/module/perfmgr/parameters/predict_freq_level#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1;dev/cpuset/top-app/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#5;sys/module/perfmgr/parameters/load_scaling_x#4;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/scaling_a#300;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_F8_40C3C000_F8#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0;dev/cpuset/top-app/cpus#3-7"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.mf.uam",
            "scene_ovrride": [
              {
                "scene_id": 10001,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0;sys/module/perfmgr/parameters/continus_no_jank_count#0;sys/module/perfmgr/parameters/scaling_a#310;sys/module/perfmgr/parameters/scaling_b#-50;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/normal_frame_keep_count#8;sys/devices/system/cpu/cpu4/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#0;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#1"
                  }
                ],
                "scene_name": "foreground",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1;sys/module/perfmgr/parameters/load_scaling_y#1;sys/module/perfmgr/parameters/scaling_a#400;sys/module/perfmgr/parameters/scaling_b#-60;sys/module/perfmgr/parameters/continus_no_jank_count#15;sys/module/perfmgr/parameters/normal_frame_keep_count#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpufreq/policy0/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy3/schedutil/pl#0;sys/devices/system/cpu/cpufreq/policy7/schedutil/pl#0;sys/devices/system/cpu/cpu0/core_ctl/enable#0;sys/devices/system/cpu/cpu3/core_ctl/enable#0;sys/devices/system/cpu/cpu7/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu4/cpufreq/schedutil/target_loads#-3 994125:-7 1435500:-11 1881000:-15 2338875:-19;sys/devices/system/cpu/cpu7/cpufreq/schedutil/target_loads#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20;sys/devices/system/cpu/cpu0/cpufreq/schedutil/target_loads#-5 940800:-14 1440000:-2;sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_0_40CE0000_0064005F_40C20100_55_40C20200_46_40C1C100_5F_40C1C200_50#0"
                  }
                ]
              }
            ]
          }
        ]
      },
      "booster_debug_log_collect_config": {
        "L3_jank_debug_log_enable": false,
        "L3_threshold_jank_percent": 10,
        "max_trace_file_num_per_game": 2,
        "trace_events": "gfx,input,view,audio,hal,power,sched,freq,idle,binder_driver,binder_lock",
        "trace_rest_time_by_second": 15
      },
      "booster_enable": true,
      "cpuset_enable": true,
      "dynamic_fps_global": {
        "dynamic_fps": "10:0,38:90,42:60,44:50,45.2:40",
        "dynamic_fps_M": "10:0,37:90,41:60,42.8:40"
      },
      "force_comp_app_list": [
        "com.miHoYo.Yuanshen:SurfaceView[com.miHoYo.Yuanshen/com.miHoYo.GetMobileInfo.MainActivity](BLAST)#400",
        "com.miHoYo.GenshinImpact:SurfaceView[com.miHoYo.GenshinImpact/com.miHoYo.GetMobileInfo.MainActivity](BLAST)#400",
        "com.miHoYo.ys.mi:SurfaceView[com.miHoYo.ys.mi/com.miHoYo.GetMobileInfo.MainActivity](BLAST)#400",
        "com.miHoYo.ys.bilibili:SurfaceView[com.miHoYo.ys.bilibili/com.miHoYo.GetMobileInfo.MainActivity](BLAST)#400",
        "com.miHoYo.hkrpg:SurfaceView[com.miHoYo.hkrpg/com.mihoyo.combosdk.ComboSDKActivity](BLAST)#400"
      ],
      "force_scale_app_list": [
        "com.tencent.tmgp.sgame:560#1.01;420#1.25:com.tencent.tmgp.sgame.SGameActivity",
        "com.tencent.tmgp.pubgmhd:560#2.25;420#1.66:com.epicgames.ue4.GameActivity",
        "com.tencent.jkchess:560#2;420#1.5:com.tencent.jkchess.ApolloZGame",
        "com.netease.g67:560#1.66;420#1.25:com.netease.game.MessiahNativeActivity",
        "com.netease.g67.mi:560#1.66;420#1.25:com.netease.game.MessiahNativeActivity"
      ],
      "gameIdentify_whitelist": [
        "com.phonetest.stresstest",
        "com.drawelements.deqp",
        "com.antutu.ABenchMark",
        "com.antutu.ABenchMark5",
        "com.antutu.benchmark.bench64",
        "com.antutu.videobench",
        "com.antutu.ABenchMark.GL2",
        "com.antutu.tester",
        "com.antutu.benchmark.full",
        "com.music.videogame",
        "com.ludashi.benchmark",
        "com.ludashi.benchmarkhd",
        "com.qihoo360.ludashi.cooling",
        "cn.opda.android.activity",
        "com.shouji.cesupaofen",
        "com.colola.mobiletest",
        "ws.j7uxli.a6urcd",
        "com.gamebench.metricscollector",
        "com.huahua.test",
        "com.futuremark.dmandroid.application",
        "com.eembc.coremark",
        "com.rightware.BasemarkOSII",
        "com.glbenchmark.glbenchmark27",
        "com.greenecomputing.linpack",
        "eu.chainfire.cfbench",
        "com.primatelabs.geekbench",
        "com.primatelabs.geekbench3",
        "com.quicinc.vellamo",
        "com.aurorasoftworks.quadrant.ui.advanced",
        "com.aurorasoftworks.quadrant.ui.standard",
        "eu.chainfire.perfmon",
        "com.evozi.deviceid",
        "com.finalwire.aida64",
        "com.cpuid.cpu_z",
        "rs.in.luka.android.pi",
        "com.uzywpq.cqlzahm",
        "com.xidige.androidinfo",
        "com.appems.hawkeye",
        "com.tyyj89.androidsuperinfo",
        "com.ft1gp",
        "ws.k6t2we.b4zyjdjv",
        "com.myapp.dongxie_app1",
        "com.shoujijiance.zj",
        "com.qrj.test",
        "com.appems.testonetest",
        "com.andromeda.androbench2",
        "com.primatelabs.geekbench5.corporate",
        "net.kishonti.gfxbench.vulkan.v50000.corporate",
        "com.antutu.ABenchMark.lite",
        "com.antutu.aibenchmark",
        "com.ludashi.benchmark2",
        "com.ludashi.aibench",
        "com.primatelabs.geekbench5c",
        "com.primatelabs.geekbench5",
        "com.primatelabs.geekbench4.corporate",
        "net.kishonti.gfxbench.gl.v40001.corporate",
        "org.benchmark.demo",
        "com.android.gputest",
        "android.test.app",
        "com.ioncannon.cpuburn.gpugflops",
        "ioncannon.com.andspecmod",
        "skynet.cputhrottlingtest"
      ],
      "game_identify": true,
      "low_display_refresh_rate_scenes": [
        1,
        2,
        3,
        4,
        5
      ],
      "migl_settings": {
        "enable": true,
        "game_params": [
          {
            "game": "yuanshen",
            "game_cmdlines": [
              "com.miHoYo.Yuanshen",
              "com.miHoYo.GenshinImpact",
              "com.miHoYo.ys.mi",
              "com.miHoYo.ys.bilibili"
            ],
            "params": {
              "tex_size": "1620x728",
              "tex_size_v2": "1440x648;1620x728;1920x864"
            }
          },
          {
            "game": "pubg",
            "game_cmdlines": [
              "com.tencent.tmgp.pubgmhd"
            ],
            "params": {
              "tex_param_anisotropy": "1"
            }
          }
        ]
      },
      "monitor": {
        "analytics_enable": false,
        "default_interval": 2,
        "monitor_enable": false
      },
      "mqs_enhance_list": [
        "com.miHoYo.hkrpg:60#default",
        "com.miHoYo.Yuanshen:60#default",
        "com.miHoYo.ys.mi:60#default"
      ],
      "predownload_enable": true,
      "qsync_enable": false,
      "recommend_tgame_thresh": "44#90",
      "scale_app_enable": true,
      "scene_id_sender_enable": true,
      "support_display_refresh_rates": [
        60,
        90,
        120
      ],
      "support_dynamic_refresh_rate_games": [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.sgame",
        "com.tencent.tmgp.sgamece",
        "com.tencent.tmgp.letsgo",
        "com.tencent.ig",
        "com.tencent.tmgp.speedmobile",
        "com.tencent.lolm",
        "com.denachina.g13002010.denacn",
        "com.denachina.g13002010.mi",
        "com.wanmei.zhuxian.mi",
        "com.wanmei.zhuxian",
        "com.netease.dwrg.mi",
        "com.netease.moba.mi",
        "com.leiting.yunshiwinter.mi",
        "com.protopop.brightridge.shiba",
        "com.protopop.brightridge",
        "com.netease.lglr",
        "com.netease.g67"
      ],
      "support_gdpvo_app": [
        "com.tencent.tmgp.sgame",
        "com.tencent.tmgp.pubgmhd",
        "com.miHoYo.enterprise.NGHSoD",
        "com.miHoYo.bh3.mi"
      ],
      "support_gt_app": [],
      "support_highfps_app": [
        "com.nd.he.mi:120",
        "com.tencent.nbn:120",
        "com.tencent.tmgp.sgame:120",
        "com.tencent.tmgp.sgamece:120",
        "com.tencent.tmgp.letsgo:60",
        "com.activision.callofduty.shooter:120",
        "com.netease.lztg1.mi:120",
        "com.netease.lztg:120",
        "com.tencent.tmgp.cf:120",
        "com.pwrd.xxajh.laohu:120",
        "com.pwrd.xxajh.mi:120",
        "com.miHoYo.bh3.mi:90",
        "com.miHoYo.bh3:90",
        "com.miHoYo.bh3.bilibili:90",
        "com.miHoYo.enterprise.NGHSoD:90",
        "com.t2ksports.nba2k20and:60",
        "com.tencent.af:120",
        "com.tencent.tmgp.pubgmhd:120",
        "com.tencent.tmgp.speedmobile:120",
        "com.tencent.tmgp.WePop:120",
        "com.tencent.YiRen:120",
        "com.tencent.KiHan:120",
        "com.gs.truckdrive.road.train.truck.gtx:60",
        "com.tencent.ig:90",
        "com.tencent.tmgp.cod:120",
        "com.tencent.tmgp.codty:120",
        "com.denachina.g13002010.mi:120",
        "com.denachina.g13002010.denacn:120",
        "com.tencent.lolm:120",
        "com.netease.harrypotter:60",
        "com.netease.harrypotter.mi:120",
        "com.netease.harrypotter.bilibili:120",
        "com.tencent.sgwsba:60",
        "com.longtugame.yjfb.mi:60",
        "com.duole.doudizhuhd.mi:60",
        "com.supercell.clashofclans.mi:120",
        "com.miHoYo.cloudgames.ys:60",
        "com.sy.dldlhsdj.mi:60",
        "com.sy.dldlhsdj.azt:60",
        "com.pwrd.hotta.laohu:120",
        "com.hottagames.hotta.mi:120",
        "com.hottagames.hotta.aligames:120",
        "com.youzu.bs.mi:120",
        "com.youzu.bs:120",
        "com.netease.g104.mi:60",
        "com.netease.g104.cn:60",
        "com.netease.moba.mi:120",
        "com.netease.moba:120",
        "com.bilibili.snake:120",
        "com.bilibili.snake.mi:120",
        "com.tencent.tmgp.djsy:90",
        "com.knight.union.mi:60",
        "com.tencent.jkchess:60",
        "com.feiyu.carrot3.mi:60",
        "com.minitech.miniworld.TMobile.mi:60",
        "com.taomee.molenew.mi:60",
        "com.bf.sgs.hdexp.mi:60",
        "com.netease.dwrg.mi:60",
        "com.bandainamcoent.dblegends_ww:60",
        "com.netease.lrs:60",
        "com.netease.lrs.mi:60",
        "com.tencent.tmgp.supercell.brawlstars:120",
        "com.cis.jiangnan.taptap:60",
        "com.wepie.snake.new.mi:60",
        "com.tencent.game.rhythmmaster:120",
        "com.miHoYo.hkrpg:60",
        "com.pwrd.pnw:120",
        "com.tencent.mf.uam:120",
        "com.tencent.mf.uamty:120",
        "com.tencent.tmgp.gnyx:120",
        "com.tencent.tmgp.codev:120",
        "com.vgamecrty.projv:120",
        "com.tencent.tmgp.supercell.clashofclans:120",
        "com.yongshi.tenojo.ys:120",
        "com.netease.tom:120",
        "com.netease.tom.mi:120",
        "com.netease.tom.m4399:120",
        "com.xd.rotaeno.googleplay:120"
      ],
      "support_motor_app": [],
      "support_predownload_app_list": [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.sgame#1"
      ],
      "support_scale_app_list": [
        "com.miHoYo.enterprise.NGHSoD",
        "com.happyelements.AndroidAnimal",
        "cn.jj",
        "com.tencent.tmgp.speedmobile",
        "com.blizzard.wtcg.hearthstone",
        "com.tencent.peng",
        "com.tencent.qqgame.xq",
        "com.qqgame.happymj",
        "com.tencent.tmgp.tstl",
        "com.tencent.wmsj",
        "com.tencent.swy",
        "com.tencent.tmgp.qqx5",
        "com.tencent.tmgp.wec",
        "com.tencent.shootgame",
        "com.tencent.tmgp.vgame",
        "com.tencent.tmgp.mt4",
        "com.tencent.woool3d",
        "com.tencent.xishanju.xj4",
        "com.tencent.tmgp.redfox",
        "com.tencent.wdqy",
        "com.tencent.YiRen",
        "com.tencent.tmgp.ylm",
        "com.tencent.yoozoo.got.wintercoming",
        "com.tencent.hxh",
        "com.tencent.tmgp.sskgame",
        "com.minitech.miniworld",
        "com.bairimeng.dmmdzz",
        "com.netease.tom",
        "com.netease.tom.mi",
        "com.netease.tom.m4399",
        "com.supercell.clashofclans.kunlun",
        "com.aligames.sgzzlb",
        "com.outfit7.talkingtomgoldrun.bd",
        "com.bf.sgs.hdexp",
        "com.lilithgames.hgame.cn",
        "com.supercell.clashroyale.kunlun",
        "com.ChillyRoom.DungeonShooter",
        "com.wepie.snake",
        "com.ledou.mhhy",
        "com.gbits.atm.leiting",
        "com.shiyi.bkby",
        "com.jiguang.dldl.sy37",
        "com.qidian.dldl.official",
        "com.papegames.nn4.cn",
        "com.wanmei.zhuxian.laohu",
        "com.qhjx.snk.sy371",
        "com.szxchd.yqxx.dodsdk",
        "com.sqw.sssf",
        "com.hermes.bgame",
        "com.netease.lx7",
        "com.taomee.huah",
        "com.soulgame.shokudo.kuaishou"
      ],
      "support_vrs_app": [
        "com.tencent.tmgp.sgame",
        "com.miHoYo.Yuanshen",
        "com.tencent.tmgp.speedmobile",
        "com.tencent.tmgp.pubgmhd",
        "com.sy.dldlhsdj.gw",
        "com.protopop.brightridge"
      ],
      "tuner_enable": true,
      "vrs_soc": "8350"
    },
    "header": {
      "index_enable": true,
      "mqs_enable": true,
      "network_improve": true,
      "version": "2024123199"
    }
}', NULL, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Auto increment value for cloud_config
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 2 WHERE name = 'cloud_config';

PRAGMA foreign_keys = true;